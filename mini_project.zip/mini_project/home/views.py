from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages
from .models import Customer
import bs4
import urllib.request
import tweepy
from textblob import TextBlob

# Create your views here.
def home(request):
    customers = Customer.objects.all()
    return render(request,'home.html',{'customers':customers})
def register(request):
    if request.method=='POST': 
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email_id']
        if password1==password2:
            if User.objects.filter(username=username).exists():
                messages.error(request,'username taken')
                return redirect('register')
            elif User.objects.filter(email=email).exists():
                messages.error(request,'email taken')
                return redirect('register')
            else:
                user=User.objects.create_user(username=username,password=password1,email=email,first_name=first_name,last_name=last_name)
                user.save()
                return redirect('/')
        else :
            messages.info(request,'password does not match')
            return redirect('register')
    else:
        return render(request,'register.html')

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        print(username,password)
        user = auth.authenticate(username=username,password=password)

        if user is not None:
            auth.login(request,user)
            return redirect('home')
        else:
            messages.error(request,'invalid user')
            return redirect('/')
    else:
        return render(request,'login.html')

def logout(request):
    auth.logout(request)
    return redirect('/')
    
def cust_det(request,id):
    customers = Customer.objects.all()
    cust = Customer.objects.get(id=id)
    scrap_url = cust.customer_url
    if cust.customer_desc == "":
        source = urllib.request.urlopen(scrap_url).read()
        soup = bs4.BeautifulSoup(source, 'lxml')
        txt = ""
        for paragraph in soup.find_all('p'):
            block = str(paragraph.text)
            if block == None:
                pass 
            else:
                txt += (str(paragraph.text))

        cust.customer_desc = txt
        cust.save() 

    return render(request,'cust_details.html',{'customers':customers,'cust':cust})

def help(request):
    customers = Customer.objects.all()
    return render(request,'help.html',{'customers':customers})

def sent_analysis(request):
    subjectivity = 0
    polarity = 0
    customers = Customer.objects.all()
    for customer in customers:
        print("inside for loop")
        consumer_key = 'C0LWk0o8DYNkqGFEzifGzWSDT'
        consumer_secret = 'Lq3OiHnbfxEDpTC589ors7X0oKzT8I7Zz5TjVfuNTrBc7C8jOa'
        access_token = '1254281737988747265-AiOVokTH7W53uwLX5kJ76GuG03FaDz'
        access_token_secret = '7UDKa3svtkxEArjxV9oeizHScRTgceMt7dW8EfxTbTaL6'
        auth = tweepy.OAuthHandler(consumer_key,consumer_secret)
        auth.set_access_token(access_token,access_token_secret)
        api = tweepy.API(auth)
        public_tweets = api.search(customer.customer_name)
        print("after search operation")
        for tweet in public_tweets:
            print(tweet.text)
            analysis = TextBlob(tweet.text)
            polarity = polarity + analysis.polarity
            subjectivity = subjectivity + analysis.subjectivity
            print(analysis.sentiment)
            print("analysis is printed above")
        customer.polarity = polarity
        customer.subjectivity = subjectivity
        customer.save()
        print("after save")
    return render(request,'tweet.html',{'customers':customers})