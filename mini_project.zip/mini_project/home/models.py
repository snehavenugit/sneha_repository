from django.db import models

class Customer(models.Model):
    customer_name = models.CharField(max_length=100)
    customer_logo = models.ImageField(upload_to='pics')
    customer_desc = models.TextField(null=True,blank=True)
    customer_url = models.CharField(max_length=1000,default="https://www.wikipedia.org/")
    polarity = models.FloatField()
    subjectivity = models.FloatField()