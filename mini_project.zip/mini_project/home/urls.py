from django.urls import path,include
from . import views

urlpatterns=[
    path('register',views.register,name='register'),
    path('',views.login,name='login'),
    path('logout',views.logout,name='logout'),
    path('home',views.home,name='home'),
    path('accounts/', include('allauth.urls')),
    path('help',views.help,name="help"),
    path('cust<id>',views.cust_det,name="cust_det"),
    path('analysis',views.sent_analysis,name="sent_analysis")
]